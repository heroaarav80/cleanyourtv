# TV Home

A tiny (~100 KB), ad-free, Apple TV 4K style launcher for Android TV / Google TV.
Plain Java, no libraries, no blur, no video, no network access. Built to run on TVs with 1 GB of RAM.

## Features
- Black home screen with a dock (4 apps), an app grid, greeting, thin clock and date
- One translucent **glass highlight** that springs from tile to tile
- **Liquid glass** mode: gel-like squash-and-stretch motion with a specular edge (Settings > Appearance)
- Top-right pill menus for **Inputs**, **Wi-Fi** and **Settings**, all in the same glass dropdown style
- **Appearance** menu inside the launcher: wallpapers, wallpaper carousel, icon style, liquid glass, rearrange apps, idle clock
- 7 built-in premium wallpapers drawn in code, plus your own images
- **Rearrange apps**: long-press OK (or press MENU) on an app, move it with the arrows, press OK to place. The first four apps form the dock
- **Idle analog clock** when the TV is not used, with customisable style, colour, seconds hand, numbers and date. Optional system screensaver
- Deterministic D-pad navigation; remembers the last focused tile

## Build
Push to GitHub and run the **build** workflow (Actions tab). Download the `tvhome` artifact.
Local build needs JDK 17, the Android SDK build-tools and an `android.jar`: `ANDROID_JAR=... ./build.sh`

## Install
```
./install.sh TV_IP
```
This installs the APK, grants the Wi-Fi and screensaver permissions and makes TV Home the default Home app.
To also disable the stock launcher (only after you have confirmed TV Home works):
```
./install.sh TV_IP <stock.launcher.package>
```
Find the package with: `adb shell cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME`

Undo: `adb shell pm enable <stock.launcher.package>`

## Customise
| What | How |
|---|---|
| Default dock apps | edit `assets/dock.txt`, rebuild |
| Fonts | drop `Outfit-Thin.ttf`, `Outfit-Light.ttf`, `Outfit-Regular.ttf` (OFL) in `assets/` |
| Your own wallpaper | `adb push photo.jpg /sdcard/Android/data/com.tvhome.launcher/files/wallpapers/` then Settings > Appearance > Wallpaper |
| Wallpaper carousel | Settings > Appearance > Wallpaper > Carousel |
| System screensaver | Settings > Appearance > Idle clock > Use as system screensaver (needs `pm grant ... WRITE_SECURE_SETTINGS`, done by install.sh) |

## Remote keys
| Key | Action |
|---|---|
| Arrows | move one tile / row |
| OK | open app or menu |
| Long OK or MENU on an app | rearrange mode |
| Back | close menu / leave move mode / jump to first dock app |

## Project layout
```
src/com/tvhome/launcher/
  MainActivity.java      launcher UI, focus, menus, wallpapers
  Wallpapers.java        procedural wallpapers
  AnalogClockView.java   idle clock
  ClockDream.java        system screensaver
```

## License
MIT. Inspired by the debloat-and-launcher idea of CleanYourTV (MIT).

package com.tvhome.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Apple TV 4K style launcher for Android TV.
 * Layout is designed on a 1920x1080 canvas and scaled to the real screen.
 * All focus handling is manual, so D-pad navigation is fully deterministic.
 */
public class MainActivity extends Activity {
    // focus zones
    static final int BAR = 0, DOCK = 1, GRID = 2, DROP = 3;
    // layout
    static final int COLS = 4, DOCK_N = 4;
    static final int ICON = 168, CELL_W = 300, CELL_H = 270, GRID_X = 360, GRID_Y = 1140, DOCK_Y = 836;
    static final int MENU_W = 600, ROW = 72, MAXV = 9;
    // menu kinds
    static final int M_INPUTS = 0, M_WIFI = 1, M_SETTINGS = 2, M_APPEARANCE = 3, M_WALLPAPER = 4, M_ICONS = 5, M_IDLE = 6;
    // menu item ids
    static final int I_NONE = 0, I_BACK = 1, I_INPUT = 2, I_SUB = 3, I_INTENT = 4, I_LIQUID = 5, I_ICON = 6,
            I_WPB = 7, I_WPF = 8, I_CAR = 9, I_CARINT = 10, I_WPADD = 11, I_IDLE = 12, I_CSTYLE = 13,
            I_CCOLOR = 14, I_CSEC = 15, I_CDATE = 16, I_CNUM = 17, I_CPREV = 18, I_DREAM = 19,
            I_MOVE = 20, I_RESET = 21;

    static final String[] ACTIONS = {
            Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_DISPLAY_SETTINGS,
            Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_SETTINGS,
            Settings.ACTION_INPUT_METHOD_SETTINGS};
    static final int[] INTERVALS = {30, 60, 300, 900};
    static final String[] INTERVAL_NAMES = {"30 sec", "1 min", "5 min", "15 min"};
    static final int[] IDLE_MINS = {0, 1, 5, 10, 30};
    static final String[] SHAPES = {"Original", "Rounded", "Circle", "Glass plate"};

    static class App {
        String label, pkg; ResolveInfo ri; Drawable icon; Intent intent; int color; boolean colored;
    }

    static class Item {
        int id, arg; String label;
        Item(int id, String label, int arg) { this.id = id; this.label = label; this.arg = arg; }
    }

    // state
    SharedPreferences sp;
    int W, H, contentH, zone = DOCK, idx = 0, menuPill = 0, menuTop = 0, carIdx = 0, animGen = 0;
    float k;
    boolean liquid, carousel, moving, idleOn, resumed, centerArmed, longDone;
    int iconShape, carInt, idleIdx;
    String wpKey;
    final List<App> apps = new ArrayList<App>();
    final List<App> dock = new ArrayList<App>();
    final List<App> grid = new ArrayList<App>();
    final List<View> tileViews = new ArrayList<View>();
    final List<View> dockV = new ArrayList<View>();
    final List<View> gridV = new ArrayList<View>();
    final List<TextView> gridL = new ArrayList<TextView>();
    final List<TvInputInfo> inputs = new ArrayList<TvInputInfo>();
    final List<File> customFiles = new ArrayList<File>();
    final List<Integer> menuKinds = new ArrayList<Integer>();
    final List<Integer> menuSel = new ArrayList<Integer>();
    List<Item> curItems = new ArrayList<Item>();
    final TextView[] pills = new TextView[3];
    final int[] pillX = {1016, 1240, 1604}, pillW = {200, 340, 220};

    FrameLayout root, content, glassV, idleLayer;
    ImageView wpA, wpB;
    ScrollView scroll;
    View shine;
    TextView bigName, hint;
    LinearLayout dropBox;
    GradientDrawable glow;
    AnalogClockView idleClock;
    ValueAnimator va;
    float[] cur;
    Bitmap bmpA;
    Typeface thin, light, reg;
    final Handler h = new Handler(Looper.getMainLooper());

    final Runnable idleRun = new Runnable() { public void run() { showIdle(); } };
    final Runnable carRun = new Runnable() {
        public void run() {
            List<String> keys = allKeys();
            if (!keys.isEmpty()) {
                carIdx = (carIdx + 1) % keys.size();
                showWallpaper(loadWp(keys.get(carIdx)), true);
            }
            restartCarousel();
        }
    };

    int s(float v) { return Math.round(v * k); }

    // ------------------------------------------------------------------ lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("s", 0);
        liquid = sp.getBoolean("liquid", false);
        iconShape = sp.getInt("shape", 0);
        carousel = sp.getBoolean("carousel", false);
        carInt = Math.min(sp.getInt("carint", 1), INTERVALS.length - 1);
        idleIdx = Math.min(sp.getInt("idle", 3), IDLE_MINS.length - 1);
        wpKey = sp.getString("wp", "b:1");
        DisplayMetrics dm = getResources().getDisplayMetrics();
        W = dm.widthPixels; H = dm.heightPixels; k = W / 1920f;
        thin = font("Outfit-Thin.ttf", "sans-serif-thin");
        light = font("Outfit-Light.ttf", "sans-serif-light");
        reg = font("Outfit-Regular.ttf", "sans-serif");
        loadApps();
        build();
        showWallpaper(loadWp(wpKey), false);
        int z = sp.getInt("z", DOCK), i = sp.getInt("i", 0);
        if (z == DOCK && i < dock.size()) { zone = z; idx = i; }
        else if (z == GRID && i < grid.size()) { zone = z; idx = i; }
        else { zone = dock.isEmpty() ? BAR : DOCK; idx = 0; }
        scroll.post(new Runnable() { public void run() { applyFocus(false); } });
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        refreshWifi();
        scanCustom();
        restartCarousel();
        armIdle();
    }

    @Override protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(idleRun);
        h.removeCallbacks(carRun);
        if (moving) endMove();
        if (idleOn) hideIdle();
        if (zone == DOCK || zone == GRID)
            sp.edit().putInt("z", zone).putInt("i", idx).apply();
    }

    @Override protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        if (moving) endMove();
        if (idleOn) hideIdle();
        if (zone == DROP) closeMenu();
        if (!dock.isEmpty()) go(DOCK, 0);
    }

    // ------------------------------------------------------------------ data
    Typeface font(String f, String fb) {
        try { return Typeface.createFromAsset(getAssets(), f); }
        catch (Exception e) { return Typeface.create(fb, Typeface.NORMAL); }
    }

    List<String> readLines(String f) {
        List<String> r = new ArrayList<String>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open(f)));
            String l;
            while ((l = br.readLine()) != null) { l = l.trim(); if (l.length() > 0 && !l.startsWith("#")) r.add(l); }
            br.close();
        } catch (Exception e) { }
        return r;
    }

    List<String> splitPref(String key) {
        List<String> r = new ArrayList<String>();
        String v = sp.getString(key, "");
        if (v.length() > 0) r.addAll(Arrays.asList(v.split(",")));
        return r;
    }

    void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (App a : apps) { if (sb.length() > 0) sb.append(','); sb.append(a.pkg); }
        sp.edit().putString("order", sb.toString()).apply();
    }

    void loadApps() {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> q = pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0);
        if (q.isEmpty()) q = pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        List<App> all = new ArrayList<App>();
        List<String> seen = new ArrayList<String>();
        for (ResolveInfo ri : q) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || seen.contains(pkg)) continue;
            Intent in = pm.getLeanbackLaunchIntentForPackage(pkg);
            if (in == null) in = pm.getLaunchIntentForPackage(pkg);
            if (in == null) continue;
            seen.add(pkg);
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            App a = new App();
            a.ri = ri; a.pkg = pkg; a.intent = in;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.icon = ri.loadIcon(pm);
            all.add(a);
        }
        Collections.sort(all, new Comparator<App>() {
            public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        List<String> want = splitPref("order");
        if (want.isEmpty()) want = readLines("dock.txt");
        apps.clear();
        for (String w : want) for (App a : all) if (a.pkg.equals(w) && !apps.contains(a)) apps.add(a);
        for (App a : all) if (!apps.contains(a)) apps.add(a);
        split();
    }

    void split() {
        dock.clear(); grid.clear();
        for (int i = 0; i < apps.size(); i++) { if (i < DOCK_N) dock.add(apps.get(i)); else grid.add(apps.get(i)); }
    }

    // ------------------------------------------------------------------ UI building
    TextView text(String t, float px, Typeface f, int color, int grav) {
        TextView v = new TextView(this);
        v.setText(t); v.setTypeface(f); v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_PX, s(px));
        v.setGravity(grav); v.setSingleLine(true); v.setEllipsize(TextUtils.TruncateAt.END);
        v.setIncludeFontPadding(false);
        return v;
    }

    void place(ViewGroup p, View v, float x, float y, float w, float h) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(s(w), s(h));
        lp.leftMargin = s(x); lp.topMargin = s(y);
        p.addView(v, lp);
    }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(s(r));
        return g;
    }

    void build() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        wpA = new ImageView(this); wpA.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wpB = new ImageView(this); wpB.setScaleType(ImageView.ScaleType.CENTER_CROP); wpB.setAlpha(0f);
        root.addView(wpA, new FrameLayout.LayoutParams(-1, -1));
        root.addView(wpB, new FrameLayout.LayoutParams(-1, -1));
        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x22000000, 0x99000000}));
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFocusable(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        int rows = (grid.size() + COLS - 1) / COLS;
        contentH = Math.max(H, s(GRID_Y + rows * CELL_H + 260));
        content = new FrameLayout(this);
        scroll.addView(content, new ViewGroup.LayoutParams(-1, contentH));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        glow = new GradientDrawable();
        glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setGradientRadius(s(760));
        glow.setColors(new int[]{0x00000000, 0x00000000});
        View g = new View(this); g.setBackground(glow);
        place(content, g, 0, 380, 1920, 640);

        place(content, text(greeting(), 34, reg, 0xAAFFFFFF, Gravity.LEFT), 96, 64, 800, 50);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm"); clock.setFormat24Hour("HH:mm");
        clock.setTypeface(thin); clock.setTextColor(Color.WHITE);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, s(170)); clock.setIncludeFontPadding(false);
        place(content, clock, 90, 110, 900, 200);
        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM"); date.setFormat24Hour("EEEE, d MMMM");
        date.setTypeface(light); date.setTextColor(0xAAFFFFFF);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, s(36)); date.setIncludeFontPadding(false);
        place(content, date, 96, 300, 900, 50);

        String[] pn = {"Inputs", "Wi-Fi", "Settings"};
        for (int i = 0; i < 3; i++) {
            TextView p = text(pn[i], 30, reg, Color.WHITE, Gravity.CENTER);
            p.setBackground(round(0x33FFFFFF, 36));
            pills[i] = p;
            place(content, p, pillX[i], 64, pillW[i], 72);
        }

        bigName = text("", 76, light, Color.WHITE, Gravity.CENTER);
        place(content, bigName, 0, 600, 1920, 100);
        View band = new View(this); band.setBackground(round(0x26FFFFFF, 64));
        place(content, band, GRID_X - 20, 804, 1240, 232);

        glassV = new FrameLayout(this);
        shine = new View(this);
        GradientDrawable sh = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0x00FFFFFF, 0xCCFFFFFF, 0x00FFFFFF});
        sh.setCornerRadius(s(4));
        shine.setBackground(sh);
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-1, Math.max(2, s(4)));
        sl.leftMargin = s(36); sl.rightMargin = s(36); sl.topMargin = s(7);
        glassV.addView(shine, sl);
        place(content, glassV, 0, 0, 10, 10);
        styleGlass();
        buildTiles();

        hint = text("Move: arrows  \u2022  OK to place", 30, reg, Color.WHITE, Gravity.CENTER);
        hint.setBackground(round(0xE61C1C1E, 40));
        hint.setVisibility(View.GONE);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(s(760), s(76), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hl.bottomMargin = s(40);
        root.addView(hint, hl);

        idleLayer = new FrameLayout(this);
        idleLayer.setBackgroundColor(Color.BLACK);
        idleClock = new AnalogClockView(this);
        idleLayer.addView(idleClock, new FrameLayout.LayoutParams(-1, -1));
        idleLayer.setVisibility(View.GONE);
        root.addView(idleLayer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    void buildTiles() {
        for (View v : tileViews) content.removeView(v);
        tileViews.clear(); dockV.clear(); gridV.clear(); gridL.clear();
        for (int i = 0; i < dock.size(); i++) {
            ImageView v = icon(dock.get(i));
            place(content, v, GRID_X + CELL_W * i + (CELL_W - ICON) / 2f, DOCK_Y, ICON, ICON);
            dockV.add(v); tileViews.add(v);
        }
        for (int i = 0; i < grid.size(); i++) {
            int r = i / COLS, c = i % COLS;
            float y = GRID_Y + CELL_H * r;
            ImageView v = icon(grid.get(i));
            place(content, v, GRID_X + CELL_W * c + (CELL_W - ICON) / 2f, y, ICON, ICON);
            gridV.add(v); tileViews.add(v);
            TextView l = text(grid.get(i).label, 28, light, Color.WHITE, Gravity.CENTER);
            l.setAlpha(0f);
            place(content, l, GRID_X + CELL_W * c, y + ICON + 36, CELL_W, 40);
            gridL.add(l); tileViews.add(l);
        }
        if (dropBox != null) dropBox.bringToFront();
    }

    ImageView icon(App a) {
        ImageView v = new ImageView(this);
        v.setImageDrawable(a.icon);
        v.setScaleType(iconShape == 1 || iconShape == 2 ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        if (iconShape != 0) {
            final boolean circle = iconShape == 2;
            v.setClipToOutline(true);
            v.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View view, Outline o) {
                    if (circle) o.setOval(0, 0, view.getWidth(), view.getHeight());
                    else o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), s(40));
                }
            });
            if (iconShape == 3) {
                v.setBackground(round(0x33FFFFFF, 40));
                int pd = s(24);
                v.setPadding(pd, pd, pd, pd);
            }
        }
        return v;
    }

    String greeting() {
        int hh = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return hh < 12 ? "Good morning" : hh < 18 ? "Good afternoon" : "Good evening";
    }

    void refreshWifi() {
        String t = "Wi-Fi";
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) {
                if (ni.getType() == ConnectivityManager.TYPE_ETHERNET) t = "Ethernet";
                else {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                    WifiInfo wi = wm.getConnectionInfo();
                    String ss = wi == null ? null : wi.getSSID();
                    if (ss != null && !ss.contains("unknown")) t = ss.replace("\"", "");
                }
            } else t = "Not connected";
        } catch (Exception e) { }
        pills[1].setText(t);
    }

    // ------------------------------------------------------------------ glass highlight
    void styleGlass() {
        GradientDrawable g;
        if (liquid) {
            g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66FFFFFF, 0x1AFFFFFF});
            g.setCornerRadius(s(48));
            g.setStroke(Math.max(2, s(3)), 0xB3FFFFFF);
            shine.setVisibility(View.VISIBLE);
        } else {
            g = round(0x40FFFFFF, 44);
            g.setStroke(Math.max(1, s(2)), 0x66FFFFFF);
            shine.setVisibility(View.GONE);
        }
        glassV.setBackground(g);
    }

    float[] rect(int z, int i) {
        if (z == BAR || z == DROP) return new float[]{pillX[i] - 6, 58, pillW[i] + 12, 84};
        float x, y;
        if (z == DOCK) { x = GRID_X + CELL_W * i + (CELL_W - ICON) / 2f; y = DOCK_Y; }
        else { x = GRID_X + CELL_W * (i % COLS) + (CELL_W - ICON) / 2f; y = GRID_Y + CELL_H * (i / COLS); }
        return new float[]{x - 24, y - 24, ICON + 48, ICON + 48 + (z == GRID ? 64 : 0)};
    }

    void setGlass(float[] r) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) glassV.getLayoutParams();
        lp.leftMargin = s(r[0]); lp.topMargin = s(r[1]); lp.width = s(r[2]); lp.height = s(r[3]);
        glassV.setLayoutParams(lp);
    }

    void moveGlass(boolean anim) {
        final float[] to = rect(zone, idx);
        animGen++;
        final int gen = animGen;
        if (va != null) va.cancel();
        glassV.setScaleX(1f); glassV.setScaleY(1f);
        if (cur == null || !anim) { cur = to.clone(); setGlass(cur); return; }
        final float[] from = cur.clone();
        final boolean horiz = Math.abs(to[0] - from[0]) >= Math.abs(to[1] - from[1]);
        final boolean lq = liquid;
        va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(lq ? 560 : 320);
        va.setInterpolator(lq ? new TimeInterpolator() {
            public float getInterpolation(float t) { return (float) (1 - Math.exp(-6 * t) * Math.cos(9 * t)); }
        } : new android.view.animation.OvershootInterpolator(1.4f));
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                for (int j = 0; j < 4; j++) cur[j] = from[j] + (to[j] - from[j]) * t;
                setGlass(cur);
                if (lq) { // squash and stretch along the direction of travel, like a drop of gel
                    float st = Math.min(1f, Math.abs(1f - t) * 1.6f) * 0.10f;
                    glassV.setScaleX(horiz ? 1f + st : 1f - st * 0.5f);
                    glassV.setScaleY(horiz ? 1f - st * 0.5f : 1f + st);
                }
            }
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) {
                if (gen != animGen) return;
                cur = to.clone(); setGlass(cur);
                glassV.setScaleX(1f); glassV.setScaleY(1f);
            }
        });
        va.start();
    }

    // ------------------------------------------------------------------ focus
    void scaleTo(View v, float sc) { v.animate().scaleX(sc).scaleY(sc).setDuration(200).start(); }

    void clearTile(int z, int i) {
        if (z == DOCK && i < dockV.size()) scaleTo(dockV.get(i), 1f);
        else if (z == GRID && i < gridV.size()) {
            scaleTo(gridV.get(i), 1f);
            gridL.get(i).animate().alpha(0f).setDuration(150).start();
        }
    }

    void setTile(int z, int i) {
        float sc = moving ? 1.22f : 1.12f;
        if (z == DOCK && i < dockV.size()) scaleTo(dockV.get(i), sc);
        else if (z == GRID && i < gridV.size()) {
            scaleTo(gridV.get(i), sc);
            gridL.get(i).animate().alpha(1f).setDuration(200).start();
        }
    }

    void applyFocus(boolean anim) {
        setTile(zone, idx);
        moveGlass(anim);
        int y = 0;
        if (zone == GRID) y = s(GRID_Y + (idx / COLS) * CELL_H - 420);
        y = Math.max(0, Math.min(Math.max(0, contentH - H), y));
        if (anim) scroll.smoothScrollTo(0, y); else scroll.scrollTo(0, y);
        if (zone == DOCK && idx < dock.size()) {
            App a = dock.get(idx);
            bigName.setText(a.label);
            bigName.setAlpha(0f); bigName.animate().alpha(1f).setDuration(180).start();
            glow.setColors(new int[]{(colorOf(a) & 0x00FFFFFF) | 0x70000000, 0x00000000});
        }
    }

    void go(int z, int i) {
        clearTile(zone, idx);
        zone = z; idx = i;
        applyFocus(true);
    }

    int colorOf(App a) {
        if (a.colored) return a.color;
        a.colored = true;
        int c = 0xFF3A6BFF;
        try {
            PackageManager pm = getPackageManager();
            Drawable d = a.ri.activityInfo.loadBanner(pm);
            if (d == null) d = a.ri.loadIcon(pm);
            Drawable.ConstantState cs = d.getConstantState();
            if (cs != null) d = cs.newDrawable();
            Bitmap b = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, 24, 24);
            d.draw(new Canvas(b));
            long r = 0, g = 0, bl = 0, n = 0;
            for (int y = 0; y < 24; y++) for (int x = 0; x < 24; x++) {
                int p = b.getPixel(x, y);
                if ((p >>> 24) < 128) continue;
                int pr = Color.red(p), pg = Color.green(p), pb = Color.blue(p);
                if (Math.max(pr, Math.max(pg, pb)) < 40) continue;
                r += pr; g += pg; bl += pb; n++;
            }
            if (n > 0) {
                float[] hsv = new float[3];
                Color.RGBToHSV((int) (r / n), (int) (g / n), (int) (bl / n), hsv);
                hsv[1] = Math.min(1f, hsv[1] * 1.25f);
                hsv[2] = Math.max(hsv[2], 0.75f);
                c = Color.HSVToColor(hsv);
            }
            b.recycle();
        } catch (Exception e) { }
        a.color = c;
        return c;
    }

    // ------------------------------------------------------------------ keys
    static boolean isCenter(int kc) {
        return kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER
                || kc == KeyEvent.KEYCODE_NUMPAD_ENTER || kc == KeyEvent.KEYCODE_BUTTON_A;
    }

    @Override public boolean onKeyDown(int kc, KeyEvent e) {
        if (idleOn) { hideIdle(); return true; }
        armIdle();
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (moving) endMove();
            else if (zone == DROP) popMenu();
            else if (!(zone == DOCK && idx == 0) && !dock.isEmpty()) go(DOCK, 0);
            return true;
        }
        if (kc == KeyEvent.KEYCODE_MENU) {
            if (moving) endMove();
            else if (zone == DOCK || zone == GRID) startMove();
            return true;
        }
        if (zone == DROP) return dropKey(kc);
        if (moving) return moveKey(kc);
        int rows = (grid.size() + COLS - 1) / COLS;
        switch (kc) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (zone == GRID) { if (idx % COLS > 0) go(GRID, idx - 1); }
                else if (idx > 0) go(zone, idx - 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (zone == BAR) { if (idx < 2) go(BAR, idx + 1); }
                else if (zone == DOCK) { if (idx < dock.size() - 1) go(DOCK, idx + 1); }
                else if (idx % COLS < COLS - 1 && idx + 1 < grid.size()) go(GRID, idx + 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (zone == GRID) {
                    if (idx >= COLS) go(GRID, idx - COLS);
                    else if (!dock.isEmpty()) go(DOCK, Math.min(idx, dock.size() - 1));
                } else if (zone == DOCK) go(BAR, Math.min(idx, 2));
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (zone == BAR) { if (!dock.isEmpty()) go(DOCK, Math.min(idx, dock.size() - 1)); }
                else if (zone == DOCK) { if (!grid.isEmpty()) go(GRID, Math.min(idx, grid.size() - 1)); }
                else if (idx + COLS < grid.size()) go(GRID, idx + COLS);
                else if (idx / COLS < rows - 1) go(GRID, grid.size() - 1);
                return true;
        }
        if (isCenter(kc)) {
            if (e.getRepeatCount() == 0) { e.startTracking(); centerArmed = true; }
            return true;
        }
        return super.onKeyDown(kc, e);
    }

    @Override public boolean onKeyUp(int kc, KeyEvent e) {
        if (isCenter(kc)) {
            boolean armed = centerArmed && !longDone;
            centerArmed = false; longDone = false;
            if (armed && !moving && zone != DROP && !idleOn) activate();
            return true;
        }
        return super.onKeyUp(kc, e);
    }

    @Override public boolean onKeyLongPress(int kc, KeyEvent e) {
        if (isCenter(kc) && (zone == DOCK || zone == GRID) && !moving) {
            longDone = true; centerArmed = false;
            startMove();
            return true;
        }
        return super.onKeyLongPress(kc, e);
    }

    @Override public void onBackPressed() { }

    void activate() {
        if (zone == BAR) { openMenu(idx); return; }
        List<App> l = zone == DOCK ? dock : grid;
        if (idx >= l.size()) return;
        try { startActivity(l.get(idx).intent); }
        catch (Exception ex) { toast("Can't open"); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    void openSettings(String act) {
        try { startActivity(new Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch (Exception e2) { toast("Can't open settings"); }
        }
    }

    // ------------------------------------------------------------------ move apps
    int globalIdx() { return zone == DOCK ? idx : DOCK_N + idx; }

    void startMove() {
        if (zone != DOCK && zone != GRID) return;
        moving = true;
        hint.setVisibility(View.VISIBLE);
        setTile(zone, idx);
    }

    void endMove() {
        moving = false;
        hint.setVisibility(View.GONE);
        saveOrder();
        applyFocus(true);
    }

    boolean moveKey(int kc) {
        int g = globalIdx(), n = apps.size(), t = g;
        switch (kc) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (zone == DOCK ? idx > 0 : idx % COLS > 0) t = g - 1;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (zone == DOCK ? idx < dock.size() - 1 : (idx % COLS < COLS - 1 && idx + 1 < grid.size())) t = g + 1;
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (g >= DOCK_N) t = g - COLS;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (g + COLS < n) t = g + COLS;
                break;
            default:
                if (isCenter(kc)) endMove();
                return true;
        }
        if (t != g) {
            Collections.swap(apps, g, t);
            split();
            zone = t < DOCK_N ? DOCK : GRID;
            idx = t < DOCK_N ? t : t - DOCK_N;
            buildTiles();
            applyFocus(true);
        }
        return true;
    }

    // ------------------------------------------------------------------ menus
    String inputLabel(TvInputInfo i) {
        CharSequence l = null;
        try { l = i.loadCustomLabel(this); } catch (Exception e) { }
        if (l == null || l.length() == 0) l = i.loadLabel(this);
        String out = l == null ? "" : l.toString();
        if (out.length() == 0) out = i.isPassthroughInput() ? "Input" : "Live TV";
        return out;
    }

    void loadInputs() {
        inputs.clear();
        try {
            TvInputManager m = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
            inputs.addAll(m.getTvInputList());
        } catch (Exception e) { }
    }

    int sel() { return menuSel.get(menuSel.size() - 1); }
    void setSel(int v) { menuSel.set(menuSel.size() - 1, v); }
    int topKind() { return menuKinds.get(menuKinds.size() - 1); }

    void openMenu(int pill) {
        menuPill = pill;
        menuKinds.clear(); menuSel.clear();
        zone = DROP;
        pushMenu(pill == 0 ? M_INPUTS : pill == 1 ? M_WIFI : M_SETTINGS);
    }

    void pushMenu(int kind) {
        if (kind == M_INPUTS) loadInputs();
        if (kind == M_WALLPAPER) scanCustom();
        menuKinds.add(kind); menuSel.add(0);
        curItems = itemsFor(kind);
        setSel(Math.min(menuKinds.size() > 1 ? 1 : 0, curItems.size() - 1));
        menuTop = 0;
        drawMenu();
    }

    void popMenu() {
        if (menuKinds.size() <= 1) { closeMenu(); return; }
        menuKinds.remove(menuKinds.size() - 1);
        menuSel.remove(menuSel.size() - 1);
        curItems = itemsFor(topKind());
        menuTop = 0;
        drawMenu();
    }

    void closeMenu() {
        if (dropBox != null) { content.removeView(dropBox); dropBox = null; }
        menuKinds.clear(); menuSel.clear();
        zone = BAR; idx = menuPill;
    }

    List<Item> itemsFor(int kind) {
        List<Item> l = new ArrayList<Item>();
        if (menuKinds.size() > 1) l.add(new Item(I_BACK, "\u2039  Back", 0));
        switch (kind) {
            case M_INPUTS:
                if (inputs.isEmpty()) l.add(new Item(I_NONE, "No inputs found", 0));
                for (int i = 0; i < inputs.size(); i++) l.add(new Item(I_INPUT, inputLabel(inputs.get(i)), i));
                break;
            case M_WIFI:
                l.add(new Item(I_INTENT, "Wi-Fi networks", 0));
                l.add(new Item(I_INTENT, "Network & Internet", 1));
                l.add(new Item(I_SUB, "Inputs", M_INPUTS));
                l.add(new Item(I_INTENT, "Bluetooth & remotes", 4));
                break;
            case M_SETTINGS:
                l.add(new Item(I_SUB, "Appearance", M_APPEARANCE));
                l.add(new Item(I_SUB, "Inputs", M_INPUTS));
                l.add(new Item(I_INTENT, "Display", 2));
                l.add(new Item(I_INTENT, "Sound", 3));
                l.add(new Item(I_INTENT, "Remotes & accessories", 4));
                l.add(new Item(I_INTENT, "Keyboard", 6));
                l.add(new Item(I_INTENT, "All Android settings", 5));
                break;
            case M_APPEARANCE:
                l.add(new Item(I_SUB, "Wallpaper", M_WALLPAPER));
                l.add(new Item(I_LIQUID, "Liquid glass", 0));
                l.add(new Item(I_SUB, "Icon style", M_ICONS));
                l.add(new Item(I_MOVE, "Rearrange apps", 0));
                l.add(new Item(I_SUB, "Idle clock", M_IDLE));
                l.add(new Item(I_RESET, "Reset appearance", 0));
                break;
            case M_ICONS:
                for (int i = 0; i < SHAPES.length; i++) l.add(new Item(I_ICON, SHAPES[i], i));
                break;
            case M_WALLPAPER:
                l.add(new Item(I_CAR, "Carousel", 0));
                l.add(new Item(I_CARINT, "Change every", 0));
                for (int i = 1; i < Wallpapers.NAMES.length; i++) l.add(new Item(I_WPB, Wallpapers.NAMES[i], i));
                l.add(new Item(I_WPB, Wallpapers.NAMES[0], 0));
                for (int i = 0; i < customFiles.size(); i++) {
                    String n = customFiles.get(i).getName();
                    int dot = n.lastIndexOf('.');
                    l.add(new Item(I_WPF, "\u2605 " + (dot > 0 ? n.substring(0, dot) : n), i));
                }
                l.add(new Item(I_WPADD, "Add your own\u2026", 0));
                break;
            case M_IDLE:
                l.add(new Item(I_IDLE, "Start after", 0));
                l.add(new Item(I_CSTYLE, "Clock style", 0));
                l.add(new Item(I_CCOLOR, "Accent colour", 0));
                l.add(new Item(I_CSEC, "Seconds hand", 0));
                l.add(new Item(I_CNUM, "Numbers (Classic)", 0));
                l.add(new Item(I_CDATE, "Show date", 0));
                l.add(new Item(I_CPREV, "Preview now", 0));
                l.add(new Item(I_DREAM, "Use as system screensaver", 0));
                break;
        }
        return l;
    }

    String valueOf(Item it) {
        switch (it.id) {
            case I_SUB: return "\u203A";
            case I_INTENT: return it.arg == 0 ? pills[1].getText().toString() : null;
            case I_LIQUID: return liquid ? "On" : "Off";
            case I_ICON: return iconShape == it.arg ? "\u2713" : null;
            case I_WPB: return (!carousel && wpKey.equals("b:" + it.arg)) ? "\u2713" : null;
            case I_WPF:
                return (!carousel && it.arg < customFiles.size()
                        && wpKey.equals("f:" + customFiles.get(it.arg).getName())) ? "\u2713" : null;
            case I_CAR: return carousel ? "On" : "Off";
            case I_CARINT: return INTERVAL_NAMES[carInt];
            case I_IDLE: return IDLE_MINS[idleIdx] == 0 ? "Off" : IDLE_MINS[idleIdx] + " min";
            case I_CSTYLE: return AnalogClockView.STYLE_NAMES[sp.getInt("clk_style", 0) % 3];
            case I_CCOLOR: return AnalogClockView.COLOR_NAMES[sp.getInt("clk_color", 0) % AnalogClockView.COLORS.length];
            case I_CSEC: return sp.getBoolean("clk_sec", true) ? "On" : "Off";
            case I_CDATE: return sp.getBoolean("clk_date", true) ? "On" : "Off";
            case I_CNUM: return sp.getBoolean("clk_num", true) ? "On" : "Off";
        }
        return null;
    }

    void drawMenu() {
        if (dropBox != null) content.removeView(dropBox);
        int n = curItems.size();
        if (n == 0) return;
        if (sel() >= n) setSel(n - 1);
        if (sel() < menuTop) menuTop = sel();
        if (sel() >= menuTop + MAXV) menuTop = sel() - MAXV + 1;
        int vis = Math.min(n, MAXV);
        dropBox = new LinearLayout(this);
        dropBox.setOrientation(LinearLayout.VERTICAL);
        dropBox.setBackground(round(0xF01C1C1E, 40));
        dropBox.setPadding(s(16), s(16), s(16), s(16));
        for (int i = menuTop; i < menuTop + vis; i++) {
            Item it = curItems.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(s(26), 0, s(26), 0);
            if (i == sel()) row.setBackground(round(0x40FFFFFF, 28));
            TextView lab = text(it.label, 30, reg, it.id == I_NONE ? 0x88FFFFFF : Color.WHITE, Gravity.CENTER_VERTICAL);
            row.addView(lab, new LinearLayout.LayoutParams(0, -1, 1f));
            String v = valueOf(it);
            if (v != null) {
                TextView t = text(v, 28, light, 0xAAFFFFFF, Gravity.CENTER_VERTICAL | Gravity.RIGHT);
                row.addView(t, new LinearLayout.LayoutParams(-2, -1));
            }
            dropBox.addView(row, new LinearLayout.LayoutParams(-1, s(ROW)));
        }
        float x = Math.min(pillX[menuPill], 1824 - MENU_W);
        place(content, dropBox, x, 150, MENU_W, 32 + ROW * vis);
    }

    boolean dropKey(int kc) {
        switch (kc) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (sel() > 0) { setSel(sel() - 1); drawMenu(); }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (sel() < curItems.size() - 1) { setSel(sel() + 1); drawMenu(); }
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (menuKinds.size() > 1) popMenu();
                break;
            default:
                if (isCenter(kc) && !curItems.isEmpty()) onItem(curItems.get(sel()));
        }
        return true;
    }

    void onItem(Item it) {
        switch (it.id) {
            case I_NONE: return;
            case I_BACK: popMenu(); return;
            case I_SUB: pushMenu(it.arg); return;
            case I_INPUT: switchInput(inputs.get(it.arg)); closeMenu(); return;
            case I_INTENT: openSettings(ACTIONS[it.arg]); closeMenu(); return;
            case I_MOVE:
                closeMenu();
                if (!dock.isEmpty()) { go(DOCK, 0); startMove(); }
                return;
            case I_CPREV: closeMenu(); showIdle(); return;
            case I_LIQUID:
                liquid = !liquid;
                sp.edit().putBoolean("liquid", liquid).apply();
                styleGlass(); moveGlass(false);
                break;
            case I_ICON:
                iconShape = it.arg;
                sp.edit().putInt("shape", iconShape).apply();
                buildTiles();
                break;
            case I_WPB: setWallpaper("b:" + it.arg); break;
            case I_WPF:
                if (it.arg < customFiles.size()) setWallpaper("f:" + customFiles.get(it.arg).getName());
                break;
            case I_CAR:
                carousel = !carousel;
                sp.edit().putBoolean("carousel", carousel).apply();
                restartCarousel();
                break;
            case I_CARINT:
                carInt = (carInt + 1) % INTERVALS.length;
                sp.edit().putInt("carint", carInt).apply();
                restartCarousel();
                break;
            case I_WPADD:
                toast("Copy images to:\n" + wpDir().getAbsolutePath()
                        + "\n(adb push photo.jpg there), then reopen this menu");
                break;
            case I_IDLE:
                idleIdx = (idleIdx + 1) % IDLE_MINS.length;
                sp.edit().putInt("idle", idleIdx).apply();
                armIdle();
                break;
            case I_CSTYLE: sp.edit().putInt("clk_style", (sp.getInt("clk_style", 0) + 1) % 3).apply(); break;
            case I_CCOLOR:
                sp.edit().putInt("clk_color", (sp.getInt("clk_color", 0) + 1) % AnalogClockView.COLORS.length).apply();
                break;
            case I_CSEC: sp.edit().putBoolean("clk_sec", !sp.getBoolean("clk_sec", true)).apply(); break;
            case I_CDATE: sp.edit().putBoolean("clk_date", !sp.getBoolean("clk_date", true)).apply(); break;
            case I_CNUM: sp.edit().putBoolean("clk_num", !sp.getBoolean("clk_num", true)).apply(); break;
            case I_DREAM: setSystemDream(); break;
            case I_RESET: resetAppearance(); break;
        }
        curItems = itemsFor(topKind());
        drawMenu();
    }

    void switchInput(TvInputInfo i) {
        try {
            Uri u = i.isPassthroughInput() ? TvContract.buildChannelUriForPassthroughInput(i.getId())
                                           : TvContract.Channels.CONTENT_URI;
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) { toast("Can't switch input"); }
    }

    void setSystemDream() {
        try {
            String c = new ComponentName(this, ClockDream.class).flattenToString();
            Settings.Secure.putString(getContentResolver(), "screensaver_components", c);
            Settings.Secure.putInt(getContentResolver(), "screensaver_enabled", 1);
            toast("Clock screensaver enabled");
        } catch (Exception e) {
            toast("Run once in Termux:\nadb shell pm grant " + getPackageName()
                    + " android.permission.WRITE_SECURE_SETTINGS");
        }
    }

    void resetAppearance() {
        sp.edit().remove("wp").remove("carousel").remove("carint").remove("liquid").remove("shape")
                .remove("idle").remove("clk_style").remove("clk_color").remove("clk_sec")
                .remove("clk_date").remove("clk_num").apply();
        liquid = false; iconShape = 0; carousel = false; carInt = 1; idleIdx = 3; wpKey = "b:1";
        styleGlass(); buildTiles(); moveGlass(false);
        showWallpaper(loadWp(wpKey), true);
        restartCarousel(); armIdle();
    }

    // ------------------------------------------------------------------ wallpapers
    File wpDir() {
        File base = getExternalFilesDir(null);
        if (base == null) base = getFilesDir();
        File d = new File(base, "wallpapers");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    void scanCustom() {
        customFiles.clear();
        File[] fs = wpDir().listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp")) customFiles.add(f);
        }
    }

    List<String> allKeys() {
        List<String> k2 = new ArrayList<String>();
        for (int i = 1; i < Wallpapers.NAMES.length; i++) k2.add("b:" + i);
        for (File f : customFiles) k2.add("f:" + f.getName());
        return k2;
    }

    Bitmap decode(File f) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int sample = 1;
        while (o.outWidth / sample > 2000) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        o.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
    }

    Bitmap loadWp(String key) {
        try {
            if (key.startsWith("f:")) {
                File f = new File(wpDir(), key.substring(2));
                if (f.exists()) { Bitmap b = decode(f); if (b != null) return b; }
                key = "b:1";
            }
            int i = 1;
            try { i = Integer.parseInt(key.substring(2)); } catch (Exception e) { }
            return Wallpapers.make(i, 960, 540);
        } catch (Throwable t) {
            return Wallpapers.make(0, 16, 9);
        }
    }

    void setWallpaper(String key) {
        wpKey = key;
        carousel = false;
        sp.edit().putString("wp", key).putBoolean("carousel", false).apply();
        restartCarousel();
        showWallpaper(loadWp(key), true);
    }

    void showWallpaper(final Bitmap nb, boolean fade) {
        final Bitmap old = bmpA;
        if (!fade || old == null) {
            wpA.setImageBitmap(nb); bmpA = nb;
            if (old != null && old != nb) old.recycle();
            return;
        }
        wpB.setImageBitmap(nb);
        wpB.setAlpha(0f);
        wpB.animate().alpha(1f).setDuration(700).withEndAction(new Runnable() {
            public void run() {
                wpA.setImageBitmap(nb); bmpA = nb;
                wpB.setAlpha(0f); wpB.setImageDrawable(null);
                if (old != null && old != nb) old.recycle();
            }
        }).start();
    }

    void restartCarousel() {
        h.removeCallbacks(carRun);
        if (carousel && resumed) h.postDelayed(carRun, INTERVALS[carInt] * 1000L);
    }

    // ------------------------------------------------------------------ idle clock
    void armIdle() {
        h.removeCallbacks(idleRun);
        int m = IDLE_MINS[idleIdx];
        if (m > 0 && resumed && !idleOn) h.postDelayed(idleRun, m * 60000L);
    }

    void showIdle() {
        if (!resumed) return;
        if (moving) endMove();
        if (zone == DROP) closeMenu();
        idleOn = true;
        idleLayer.setVisibility(View.VISIBLE);
        idleClock.invalidate();
    }

    void hideIdle() {
        idleOn = false;
        idleLayer.setVisibility(View.GONE);
        armIdle();
    }
}

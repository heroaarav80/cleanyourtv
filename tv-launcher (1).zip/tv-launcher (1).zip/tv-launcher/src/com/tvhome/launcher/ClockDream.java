package com.tvhome.launcher;

import android.service.dreams.DreamService;

/** System screensaver that shows the same customisable analog clock. */
public class ClockDream extends DreamService {
    @Override public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setContentView(new AnalogClockView(this));
    }
}

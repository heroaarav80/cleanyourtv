package com.tvhome.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

/** Procedural premium wallpapers: no image files, no blur, a few KB of code. */
public final class Wallpapers {
    private Wallpapers() { }

    public static final String[] NAMES = {
            "Pure Black", "Midnight Aurora", "Graphite", "Ember", "Deep Ocean", "Dusk", "Emerald Night", "Silk"};

    public static Bitmap make(int i, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        switch (i) {
            case 1:
                fill(c, w, h, 0xFF050813, 0xFF000000);
                glow(c, w * .15f, h * .05f, w * .75f, 0x19D3C5, 90);
                glow(c, w * .90f, h * .20f, w * .60f, 0x7B4DFF, 85);
                glow(c, w * .50f, h * 1.10f, w * .90f, 0x0B5FFF, 70);
                band(c, w, h, h * .30f, h * .12f, h * .10f, 0x19D3C5, 70, 0);
                band(c, w, h, h * .42f, h * .10f, h * .07f, 0x7B4DFF, 55, h * .05f);
                vignette(c, w, h);
                break;
            case 2:
                fill(c, w, h, 0xFF1C1E23, 0xFF050506);
                glow(c, w * .5f, -h * .1f, w * .85f, 0xFFFFFF, 45);
                glow(c, w * .9f, h * 1.0f, w * .6f, 0x8899AA, 25);
                vignette(c, w, h);
                break;
            case 3:
                fill(c, w, h, 0xFF0B0405, 0xFF000000);
                glow(c, w * .5f, h * 1.08f, w * .85f, 0xFF5A1F, 130);
                glow(c, w * .12f, h * .95f, w * .5f, 0xFF2D55, 70);
                vignette(c, w, h);
                break;
            case 4:
                fill(c, w, h, 0xFF001327, 0xFF000510);
                glow(c, w * .72f, h * .18f, w * .80f, 0x00B4FF, 75);
                glow(c, w * .10f, h * .95f, w * .70f, 0x0047FF, 75);
                band(c, w, h, h * .62f, h * .10f, h * .06f, 0x00B4FF, 40, 0);
                vignette(c, w, h);
                break;
            case 5:
                fill(c, w, h, 0xFF10071B, 0xFF020108);
                glow(c, w * .82f, h * .15f, w * .70f, 0xFF4FA3, 85);
                glow(c, w * .08f, h * .65f, w * .70f, 0x7A3CFF, 85);
                vignette(c, w, h);
                break;
            case 6:
                fill(c, w, h, 0xFF00110D, 0xFF000302);
                glow(c, w * .30f, h * .20f, w * .70f, 0x00E58F, 70);
                glow(c, w * .92f, h * .90f, w * .60f, 0x00A3FF, 45);
                vignette(c, w, h);
                break;
            case 7:
                fill(c, w, h, 0xFF0C0C12, 0xFF020203);
                band(c, w, h, h * .20f, h * .18f, h * .16f, 0xFFFFFF, 26, 0);
                band(c, w, h, h * .38f, h * .16f, h * .14f, 0xBFD2FF, 22, h * .06f);
                band(c, w, h, h * .56f, h * .14f, h * .12f, 0xFFFFFF, 18, -h * .04f);
                band(c, w, h, h * .72f, h * .12f, h * .10f, 0xD9C7FF, 16, h * .05f);
                vignette(c, w, h);
                break;
            default:
                c.drawColor(0xFF000000);
        }
        return b;
    }

    private static void fill(Canvas c, int w, int h, int top, int bottom) {
        Paint p = new Paint();
        p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    private static void glow(Canvas c, float cx, float cy, float r, int rgb, int alpha) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, r, (alpha << 24) | (rgb & 0xFFFFFF),
                rgb & 0xFFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, c.getWidth(), c.getHeight(), p);
    }

    private static void vignette(Canvas c, int w, int h) {
        Paint p = new Paint();
        float r = (float) Math.hypot(w, h) * .62f;
        p.setShader(new RadialGradient(w / 2f, h / 2f, r, 0x00000000, 0xAA000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
    }

    /** Soft translucent ribbon, used for aurora and silk effects. */
    private static void band(Canvas c, int w, int h, float y0, float amp, float thick, int rgb, int alpha, float phase) {
        Path p = new Path();
        p.moveTo(0, y0);
        p.cubicTo(w * .3f, y0 - amp + phase, w * .6f, y0 + amp + phase, w, y0 - amp * .4f);
        p.lineTo(w, y0 - amp * .4f + thick);
        p.cubicTo(w * .6f, y0 + amp + phase + thick * 1.2f, w * .3f, y0 - amp + phase + thick * .8f, 0, y0 + thick);
        p.close();
        Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
        int clear = rgb & 0xFFFFFF;
        pt.setShader(new LinearGradient(0, 0, w, 0, new int[]{clear, (alpha << 24) | clear, clear},
                new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(p, pt);
    }
}

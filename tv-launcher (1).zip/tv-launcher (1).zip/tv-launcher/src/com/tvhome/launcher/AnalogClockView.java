package com.tvhome.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** Customisable analog clock used for the idle screen and the system screensaver. */
public class AnalogClockView extends View {
    public static final int[] COLORS = {0xFFFFFFFF, 0xFFFFD27A, 0xFF6EE7F9, 0xFFFF8FB1, 0xFF8CF5B0};
    public static final String[] COLOR_NAMES = {"White", "Gold", "Cyan", "Rose", "Mint"};
    public static final String[] STYLE_NAMES = {"Classic", "Minimal", "Modern"};

    private final SharedPreferences sp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault());
    private Typeface font;

    public AnalogClockView(Context c) {
        super(c);
        sp = c.getSharedPreferences("s", 0);
        try { font = Typeface.createFromAsset(c.getAssets(), "Outfit-Light.ttf"); }
        catch (Exception e) { font = Typeface.create("sans-serif-light", Typeface.NORMAL); }
    }

    @Override protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        cv.drawColor(Color.BLACK);
        long now = System.currentTimeMillis();
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(now);
        float hr = cal.get(Calendar.HOUR), mi = cal.get(Calendar.MINUTE), se = cal.get(Calendar.SECOND);
        int style = sp.getInt("clk_style", 0) % 3;
        int color = COLORS[sp.getInt("clk_color", 0) % COLORS.length];
        boolean secs = sp.getBoolean("clk_sec", true);
        boolean date = sp.getBoolean("clk_date", true);
        boolean nums = sp.getBoolean("clk_num", true);

        float r = Math.min(w, h) * 0.36f;
        long m = now / 60000L; // slow drift every minute protects the panel from burn-in
        float cx = w / 2f + (float) Math.sin(m * 0.9) * w * 0.015f;
        float cy = h / 2f + (float) Math.cos(m * 0.7) * h * 0.015f - (date ? r * 0.08f : 0f);

        p.setStrokeCap(Paint.Cap.ROUND);
        if (style == 0) {
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x33FFFFFF);
            p.setStrokeWidth(r * 0.012f);
            cv.drawCircle(cx, cy, r, p);
            for (int i = 0; i < 60; i++) {
                boolean big = i % 5 == 0;
                float a = (float) Math.toRadians(i * 6);
                float s = (float) Math.sin(a), c = (float) Math.cos(a);
                float r1 = r * (big ? 0.90f : 0.95f), r2 = r * 0.985f;
                p.setColor(big ? color : 0x66FFFFFF);
                p.setStrokeWidth(r * (big ? 0.018f : 0.008f));
                cv.drawLine(cx + r1 * s, cy - r1 * c, cx + r2 * s, cy - r2 * c, p);
            }
            if (nums) {
                p.setStyle(Paint.Style.FILL);
                p.setTypeface(font);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(r * 0.13f);
                p.setColor(0xDDFFFFFF);
                for (int i = 1; i <= 12; i++) {
                    float a = (float) Math.toRadians(i * 30);
                    float rr = r * 0.77f;
                    cv.drawText(String.valueOf(i), cx + rr * (float) Math.sin(a),
                            cy - rr * (float) Math.cos(a) + r * 0.045f, p);
                }
            }
        } else if (style == 1) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            for (int i = 0; i < 4; i++) {
                float a = (float) Math.toRadians(i * 90);
                cv.drawCircle(cx + r * 0.92f * (float) Math.sin(a), cy - r * 0.92f * (float) Math.cos(a), r * 0.02f, p);
            }
        } else {
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 60; i++) {
                boolean big = i % 5 == 0;
                float a = (float) Math.toRadians(i * 6);
                p.setColor(big ? color : 0x55FFFFFF);
                cv.drawCircle(cx + r * 0.95f * (float) Math.sin(a), cy - r * 0.95f * (float) Math.cos(a),
                        r * (big ? 0.022f : 0.009f), p);
            }
        }

        float ha = (hr % 12) * 30f + mi * 0.5f, ma = mi * 6f + se * 0.1f, sa = se * 6f;
        hand(cv, cx, cy, ha, r * 0.52f, r * (style == 1 ? 0.03f : 0.045f), 0xFFFFFFFF);
        hand(cv, cx, cy, ma, r * 0.78f, r * (style == 1 ? 0.02f : 0.03f), 0xFFFFFFFF);
        if (secs) {
            if (style == 2) {
                float a = (float) Math.toRadians(sa);
                p.setStyle(Paint.Style.FILL);
                p.setColor(color);
                cv.drawCircle(cx + r * 0.84f * (float) Math.sin(a), cy - r * 0.84f * (float) Math.cos(a), r * 0.035f, p);
            } else {
                hand(cv, cx, cy, sa, r * 0.88f, r * 0.010f, color);
                hand(cv, cx, cy, sa + 180f, r * 0.14f, r * 0.010f, color);
            }
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        cv.drawCircle(cx, cy, r * 0.03f, p);

        if (date) {
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(font);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(r * 0.12f);
            p.setColor(0xAAFFFFFF);
            cv.drawText(dateFmt.format(cal.getTime()), cx, cy + r * 1.30f, p);
        }
        if (isShown()) postInvalidateDelayed(secs ? 1000 : 20000);
    }

    private void hand(Canvas cv, float cx, float cy, float deg, float len, float width, int color) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(color);
        p.setStrokeWidth(width);
        float a = (float) Math.toRadians(deg);
        cv.drawLine(cx, cy, cx + len * (float) Math.sin(a), cy - len * (float) Math.cos(a), p);
    }
}

#!/data/data/com.termux/files/usr/bin/bash
# Needs: openjdk-17, aapt2, apksigner, d8 and an android.jar (API 28+). Set ANDROID_JAR if elsewhere.
set -e
cd "$(dirname "$0")"
: "${ANDROID_JAR:=$HOME/android-sdk/platforms/android-28/android.jar}"
rm -rf build; mkdir -p build/obj build/dex
[ -f debug.keystore ] || keytool -genkeypair -keystore debug.keystore -storepass android -keypass android \
  -alias debug -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=debug"
aapt2 link -o build/base.apk -I "$ANDROID_JAR" --manifest AndroidManifest.xml -A assets
javac -source 8 -target 8 -bootclasspath "$ANDROID_JAR" -d build/obj $(find src -name '*.java')
d8 --release --min-api 21 --lib "$ANDROID_JAR" --output build/dex $(find build/obj -name '*.class')
cp build/base.apk build/app.apk
(cd build/dex && zip -q ../app.apk classes.dex)
apksigner sign --ks debug.keystore --ks-pass pass:android --key-pass pass:android \
  --out build/tvhome-signed.apk build/app.apk
echo "Built build/tvhome-signed.apk"

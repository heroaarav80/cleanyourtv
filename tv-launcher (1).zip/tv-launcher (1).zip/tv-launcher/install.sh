#!/data/data/com.termux/files/usr/bin/bash
# Usage: ./install.sh TV_IP [stock_launcher_package_to_disable]
# Pass the 2nd argument only AFTER you have seen the new launcher open on the TV.
set -e
cd "$(dirname "$0")"
APK="${APK:-build/tvhome-signed.apk}"
TV="$1:5555"; STOCK="$2"; PKG=com.tvhome.launcher
adb connect "$TV"
adb -s "$TV" install -r -g "$APK"
adb -s "$TV" shell pm grant $PKG android.permission.ACCESS_FINE_LOCATION || true     # Wi-Fi name
adb -s "$TV" shell pm grant $PKG android.permission.WRITE_SECURE_SETTINGS || true    # screensaver switch
adb -s "$TV" shell cmd package set-home-activity --user 0 $PKG/.MainActivity || \
adb -s "$TV" shell cmd role add-role-holder --user 0 android.app.role.HOME $PKG || true
if [ -n "$STOCK" ]; then adb -s "$TV" shell pm disable-user --user 0 "$STOCK"; fi
adb -s "$TV" shell input keyevent KEYCODE_HOME
